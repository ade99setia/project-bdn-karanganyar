import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SalesVisitPhotoController::store
 * @see app/Http/Controllers/SalesVisitPhotoController.php:11
 * @route '/visits/{visit}/photos'
 */
export const store = (args: { visit: number | { id: number } } | [visit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/visits/{visit}/photos',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesVisitPhotoController::store
 * @see app/Http/Controllers/SalesVisitPhotoController.php:11
 * @route '/visits/{visit}/photos'
 */
store.url = (args: { visit: number | { id: number } } | [visit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { visit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { visit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    visit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        visit: typeof args.visit === 'object'
                ? args.visit.id
                : args.visit,
                }

    return store.definition.url
            .replace('{visit}', parsedArgs.visit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesVisitPhotoController::store
 * @see app/Http/Controllers/SalesVisitPhotoController.php:11
 * @route '/visits/{visit}/photos'
 */
store.post = (args: { visit: number | { id: number } } | [visit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesVisitPhotoController::store
 * @see app/Http/Controllers/SalesVisitPhotoController.php:11
 * @route '/visits/{visit}/photos'
 */
    const storeForm = (args: { visit: number | { id: number } } | [visit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesVisitPhotoController::store
 * @see app/Http/Controllers/SalesVisitPhotoController.php:11
 * @route '/visits/{visit}/photos'
 */
        storeForm.post = (args: { visit: number | { id: number } } | [visit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const SalesVisitPhotoController = { store }

export default SalesVisitPhotoController