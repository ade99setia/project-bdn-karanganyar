import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SalesAttendanceController::checkIn
 * @see app/Http/Controllers/SalesAttendanceController.php:15
 * @route '/attendance/check-in'
 */
export const checkIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkIn.url(options),
    method: 'post',
})

checkIn.definition = {
    methods: ["post"],
    url: '/attendance/check-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesAttendanceController::checkIn
 * @see app/Http/Controllers/SalesAttendanceController.php:15
 * @route '/attendance/check-in'
 */
checkIn.url = (options?: RouteQueryOptions) => {
    return checkIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesAttendanceController::checkIn
 * @see app/Http/Controllers/SalesAttendanceController.php:15
 * @route '/attendance/check-in'
 */
checkIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkIn.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesAttendanceController::checkIn
 * @see app/Http/Controllers/SalesAttendanceController.php:15
 * @route '/attendance/check-in'
 */
    const checkInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkIn.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesAttendanceController::checkIn
 * @see app/Http/Controllers/SalesAttendanceController.php:15
 * @route '/attendance/check-in'
 */
        checkInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkIn.url(options),
            method: 'post',
        })
    
    checkIn.form = checkInForm
/**
* @see \App\Http\Controllers\SalesAttendanceController::checkOut
 * @see app/Http/Controllers/SalesAttendanceController.php:60
 * @route '/attendance/check-out'
 */
export const checkOut = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkOut.url(options),
    method: 'post',
})

checkOut.definition = {
    methods: ["post"],
    url: '/attendance/check-out',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SalesAttendanceController::checkOut
 * @see app/Http/Controllers/SalesAttendanceController.php:60
 * @route '/attendance/check-out'
 */
checkOut.url = (options?: RouteQueryOptions) => {
    return checkOut.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesAttendanceController::checkOut
 * @see app/Http/Controllers/SalesAttendanceController.php:60
 * @route '/attendance/check-out'
 */
checkOut.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkOut.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SalesAttendanceController::checkOut
 * @see app/Http/Controllers/SalesAttendanceController.php:60
 * @route '/attendance/check-out'
 */
    const checkOutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkOut.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SalesAttendanceController::checkOut
 * @see app/Http/Controllers/SalesAttendanceController.php:60
 * @route '/attendance/check-out'
 */
        checkOutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkOut.url(options),
            method: 'post',
        })
    
    checkOut.form = checkOutForm
const SalesAttendanceController = { checkIn, checkOut }

export default SalesAttendanceController