import DashboardController from './DashboardController'
import SalesAttendanceController from './SalesAttendanceController'
import SalesVisitController from './SalesVisitController'
import SalesVisitPhotoController from './SalesVisitPhotoController'
import Settings from './Settings'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
SalesAttendanceController: Object.assign(SalesAttendanceController, SalesAttendanceController),
SalesVisitController: Object.assign(SalesVisitController, SalesVisitController),
SalesVisitPhotoController: Object.assign(SalesVisitPhotoController, SalesVisitPhotoController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers