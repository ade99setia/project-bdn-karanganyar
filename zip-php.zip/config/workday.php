<?php

return [
    'weekend_days' => [0],
    'holidays' => [],
];
