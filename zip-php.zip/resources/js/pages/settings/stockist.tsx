export { default } from '../../components/settings/stockist/stockist-settings-page';
