
import type * as faceapi from 'face-api.js';
import type {
    WithFaceExpressions,
    FaceExpressions,
} from 'face-api.js';
import { X, Loader2, ScanFace, CheckCircle2, Camera } from 'lucide-react';
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { toast } from 'react-hot-toast';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';

interface Props {
    isOpen: boolean;
    onClose: () => void;
    onVerified: (type: 'in' | 'out') => void;
    checkType: 'in' | 'out';
    storedDescriptor: string;
    userName: string;
}

export default function FaceVerificationModal({
    isOpen,
    onClose,
    onVerified,
    checkType,
    storedDescriptor,
    userName,
}: Props) {
    const videoRef = useRef<HTMLVideoElement>(null);
    const faceApiRef = useRef<typeof faceapi | null>(null);
    const faceApiPromiseRef = useRef<Promise<typeof faceapi> | null>(null);
    const [isLoadingModels, setIsLoadingModels] = useState(true);
    const [cameraStarted, setCameraStarted] = useState(false);
    const [cameraError, setCameraError] = useState<string | null>(null);
    const [step, setStep] = useState<'ready' | 'match' | 'smile1' | 'neutral1' | 'smile2' | 'success'>('ready');
    const [feedback, setFeedback] = useState("Menyiapkan verifikasi wajah...");
    const [isCameraWarmingUp, setIsCameraWarmingUp] = useState(false);

    const streamRef = useRef<MediaStream | null>(null);
    const requestRef = useRef<number | undefined>(undefined);
    const sessionTimeoutRef = useRef<number | undefined>(undefined);
    const targetDescriptorRef = useRef<Float32Array | null>(null);
    const stepRef = useRef(step);
    const lastDetectionTimeRef = useRef(0);
    const isProcessingRef = useRef(false);
    const mismatchCountRef = useRef(0);
    const hasScanStartedRef = useRef(false);
    // Ref tambahan untuk menjaga status kamera tanpa menunggu re-render state
    const isCameraActiveRef = useRef(false);
    const MATCH_THRESHOLD = 0.55;
    const LIVENESS_MATCH_THRESHOLD = 0.6;
    const MAX_CONSECUTIVE_MISMATCH = 4;
    const CAMERA_SESSION_TIMEOUT_MS = 60_000;

    // Update ref saat state berubah
    useEffect(() => {
        stepRef.current = step;
    }, [step]);

    const updateFeedback = useCallback((text: string) => {
        setFeedback((prev) => (prev === text ? prev : text));
    }, []);

    const loadFaceApi = useCallback(async () => {
        if (faceApiRef.current) return faceApiRef.current;
        if (!faceApiPromiseRef.current) {
            faceApiPromiseRef.current = import('face-api.js');
        }
        faceApiRef.current = await faceApiPromiseRef.current;
        return faceApiRef.current;
    }, []);

    useEffect(() => {
        if (!cameraStarted || step === 'success') return;

        const stepInstruction: Record<'match' | 'smile1' | 'neutral1' | 'smile2', string> = {
            match: 'Memvalidasi identitas...',
            smile1: 'Tahap 1/3 · Tersenyum lebar 😄',
            neutral1: 'Tahap 2/3 · Kembali netral 😐',
            smile2: 'Tahap 3/3 · Tersenyum sekali lagi 😄',
        };

        if (step in stepInstruction) {
            updateFeedback(stepInstruction[step as keyof typeof stepInstruction]);
        }
    }, [cameraStarted, step, updateFeedback]);

    // FUNGSI 1: Stop Kamera yang Stabil
    const stopCamera = useCallback(() => {
        console.log("Stopping camera...");
        isCameraActiveRef.current = false; // Matikan flag loop segera
        hasScanStartedRef.current = false;
        setIsCameraWarmingUp(false);

        if (sessionTimeoutRef.current) {
            window.clearTimeout(sessionTimeoutRef.current);
            sessionTimeoutRef.current = undefined;
        }

        if (streamRef.current) {
            streamRef.current.getTracks().forEach((t) => t.stop());
            streamRef.current = null;
        }
        if (requestRef.current) {
            cancelAnimationFrame(requestRef.current);
            requestRef.current = undefined;
        }
        if (videoRef.current) {
            videoRef.current.srcObject = null;
        }
        setCameraStarted(false);
    }, []);

    // FUNGSI 2: Handle Success
    const handleSuccess = useCallback(() => {
        if (stepRef.current === 'success') return;
        setStep('success');
        updateFeedback("Verifikasi Berhasil ✓");

        // Jangan langsung stop camera agar transisi smooth, tapi stop deteksi
        isCameraActiveRef.current = false;

        setTimeout(() => {
            stopCamera(); // Baru matikan kamera fisik
            onVerified(checkType);
            onClose();
        }, 1400);
    }, [checkType, onVerified, onClose, stopCamera, updateFeedback]);

    const getStepNumber = () => {
        switch (step) {
            case 'match': return 0;
            case 'smile1': return 1;
            case 'neutral1': return 2;
            case 'smile2':
            case 'success':
                return 3;
            default: return 0;
        }
    };

    const getProgressLabel = () => {
        const currentStep = getStepNumber();
        if (currentStep === 0) return 'Memvalidasi identitas...';
        return `Langkah ${currentStep} / 3`;
    };

    const verifyCurrentFaceOwner = useCallback((faceapiInstance: typeof faceapi, descriptor: Float32Array, threshold = MATCH_THRESHOLD) => {
        if (!targetDescriptorRef.current) return false;
        const distance = faceapiInstance.euclideanDistance(descriptor, targetDescriptorRef.current);
        return distance <= threshold;
    }, [MATCH_THRESHOLD]);

    // FUNGSI 3: Logika Liveness (Tantangan Wajah)
    const runLivenessChallenge = useCallback(
        (detection: WithFaceExpressions<{ expressions: FaceExpressions }>) => {
            const { expressions } = detection;
            const currentStep = stepRef.current;

            switch (currentStep) {
                case 'smile1':
                    if (expressions.happy > 0.65) setStep('neutral1');
                    break;
                case 'neutral1':
                    if (expressions.neutral > 0.6) setStep('smile2');
                    break;
                case 'smile2':
                    if (expressions.happy > 0.65) handleSuccess();
                    break;
                default:
                    break;
            }
        },
        [handleSuccess]
    );

    // FUNGSI 4: Loop Deteksi Wajah
    const detectFace = useCallback(async () => {
        // Cek Ref, bukan State, agar tidak terpengaruh re-render lambat
        if (!isCameraActiveRef.current || !videoRef.current || !targetDescriptorRef.current) return;

        const video = videoRef.current;

        // Validasi elemen video
        if (video.paused || video.ended || video.videoWidth === 0) {
            // Jika video belum siap, coba lagi frame berikutnya tanpa mematikan logic
            requestRef.current = requestAnimationFrame(detectFace);
            return;
        }

        // Throttle deteksi agar tidak memberatkan CPU (max 10-15 FPS)
        const now = performance.now();
        if (now - lastDetectionTimeRef.current < 100) {
            requestRef.current = requestAnimationFrame(detectFace);
            return;
        }
        lastDetectionTimeRef.current = now;

        if (isProcessingRef.current) {
            requestRef.current = requestAnimationFrame(detectFace);
            return;
        }

        if (!hasScanStartedRef.current) {
            hasScanStartedRef.current = true;
        }

        isProcessingRef.current = true;

        try {
            const faceapi = await loadFaceApi();
            // Menggunakan TinyFaceDetector agar cepat di mobile
            const useTinyModel = new faceapi.TinyFaceDetectorOptions({ inputSize: 128, scoreThreshold: 0.5 });

            let detection;

            // Logika deteksi
            if (stepRef.current === 'match') {
                // Saat matching awal, kita butuh descriptor
                const result = await faceapi
                    .detectSingleFace(video, useTinyModel)
                    .withFaceLandmarks()
                    .withFaceDescriptor()
                    .withFaceExpressions();

                if (result) {
                    if (!verifyCurrentFaceOwner(faceapi, result.descriptor)) {
                        updateFeedback("Wajah tidak cocok / Bukan pemilik akun");
                        mismatchCountRef.current = 0;
                    } else {
                        // Wajah cocok, lanjut ke liveness check
                        mismatchCountRef.current = 0;
                        setStep('smile1');
                        // Langsung cek ekspresi juga biar responsif
                        runLivenessChallenge(result);
                    }
                } else {
                    updateFeedback("Posisikan wajah di tengah");
                }
                setIsCameraWarmingUp(false);

            } else {
                // Step liveness challenge: tetap verifikasi descriptor agar tidak bisa digantikan wajah lain
                detection = await faceapi
                    .detectSingleFace(video, useTinyModel)
                    .withFaceLandmarks()
                    .withFaceDescriptor()
                    .withFaceExpressions();

                if (detection) {
                    const isSamePerson = verifyCurrentFaceOwner(faceapi, detection.descriptor, LIVENESS_MATCH_THRESHOLD);

                    if (!isSamePerson) {
                        mismatchCountRef.current += 1;
                        if (mismatchCountRef.current >= MAX_CONSECUTIVE_MISMATCH) {
                            mismatchCountRef.current = 0;
                            setStep('match');
                        }
                    } else {
                        mismatchCountRef.current = 0;
                        runLivenessChallenge(detection);
                    }
                }
            }
        } catch (err) {
            console.error("Detection glitch:", err);
        } finally {
            isProcessingRef.current = false;
            // Lanjut ke frame berikutnya jika kamera masih aktif
            if (isCameraActiveRef.current) {
                requestRef.current = requestAnimationFrame(detectFace);
            }
        }
    }, [loadFaceApi, runLivenessChallenge, updateFeedback, verifyCurrentFaceOwner]);

    // FUNGSI 5: Start Kamera
    const startCameraAndDetection = useCallback(async () => {
        setCameraError(null);
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: 'user',
                    width: { ideal: 640 },
                    height: { ideal: 480 }
                },
                audio: false
            });

            streamRef.current = stream;

            if (videoRef.current) {
                videoRef.current.srcObject = stream;

                // Promise untuk memastikan video benar-benar play
                await new Promise<void>((resolve) => {
                    videoRef.current!.onloadedmetadata = () => {
                        videoRef.current!.play().then(() => resolve());
                    };
                });

                // Set flag aktif
                isCameraActiveRef.current = true;
                setCameraStarted(true);
                setStep('match');
                mismatchCountRef.current = 0;
                hasScanStartedRef.current = false;

                if (sessionTimeoutRef.current) {
                    window.clearTimeout(sessionTimeoutRef.current);
                    sessionTimeoutRef.current = undefined;
                }

                sessionTimeoutRef.current = window.setTimeout(() => {
                    if (!isCameraActiveRef.current || stepRef.current === 'success') return;

                    stopCamera();
                    setCameraError('Sesi kamera berakhir otomatis setelah 1 menit. Silakan buka kamera lagi.');
                    updateFeedback('Waktu verifikasi habis. Silakan buka kamera lagi.');
                }, CAMERA_SESSION_TIMEOUT_MS);

                // Tampilkan warming up bersamaan dengan proses persiapan scan nyata
                detectFace();
            }
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
        } catch (err: any) {
            console.error("Camera error:", err);
            isCameraActiveRef.current = false;
            hasScanStartedRef.current = false;
            let msg = "Gagal membuka kamera";
            if (err.name === 'NotAllowedError') msg = "Izin kamera ditolak";
            if (err.name === 'NotFoundError') msg = "Kamera tidak ditemukan";
            if (err.name === 'NotReadableError') msg = "Kamera sedang digunakan aplikasi lain";

            setCameraError(msg);
            setCameraStarted(false);
            toast.error(msg);
        }
    }, [detectFace, stopCamera, updateFeedback]);

    // EFFECT 1: Load Models (Hanya dijalankan SEKALI saat mount/open)
    useEffect(() => {
        if (!isOpen) return;

        // Parse descriptor user
        if (storedDescriptor) {
            try {
                const parsed = JSON.parse(storedDescriptor);
                targetDescriptorRef.current = new Float32Array(parsed);
            } catch (e) {
                console.error("Invalid descriptor format", e);
                toast.error("Data wajah invalid");
                onClose();
                return;
            }
        }

        const loadModels = async () => {
            try {
                const faceapi = await loadFaceApi();
                // Cek apakah model sudah load sebelumnya (global check)
                const isLoaded = !!faceapi.nets.tinyFaceDetector.params;

                if (!isLoaded) {
                    updateFeedback("Memuat model AI...");
                    const MODEL_URL = '/models';
                    await Promise.all([
                        faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
                        faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
                        faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
                        faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL),
                    ]);
                    setIsCameraWarmingUp(true);
                }

                setIsLoadingModels(false);
            } catch (e) {
                console.error("Model load error:", e);
                toast.error("Gagal memuat model AI");
                onClose();
            }
        };

        loadModels();

        // PENTING: Jangan masukkan cleanup stopCamera di sini!
        // Biarkan loadModels independen dari lifecycle kamera.
    }, [isOpen, storedDescriptor, onClose, updateFeedback, loadFaceApi]);

    // EFFECT 2: Cleanup Handle saat Close Modal
    useEffect(() => {
        // Hanya jalankan cleanup jika isOpen berubah menjadi false
        if (!isOpen) {
            stopCamera();
        }

        // Cleanup function saat unmount komponen total
        return () => {
            stopCamera();
        };
    }, [isOpen, stopCamera]);


    // RENDER UI
    return (
        <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
            <DialogContent showCloseButton={false} className="w-screen h-dvh max-w-none rounded-none border-0 p-0 m-0 bg-linear-to-br from-gray-950 via-indigo-950 to-black flex flex-col overflow-hidden">
                <div className="relative w-full h-full">
                    {/* Video Element */}
                    <video
                        ref={videoRef}
                        muted
                        playsInline
                        className={`w-full h-full object-cover transform -scale-x-100 transition-opacity duration-500 ${cameraStarted ? 'opacity-100' : 'opacity-0'}`}
                    />

                    {/* Overlay UI */}
                    <div className="absolute top-0 inset-0 flex flex-col justify-between p-5 md:p-8 z-10 pointer-events-none">

                        {/* Header */}
                        <div className="flex items-center justify-between pointer-events-auto">
                            <div className="flex items-center gap-3 bg-black/40 backdrop-blur-lg px-4 py-2 rounded-full border border-cyan-500/20">
                                <ScanFace className="h-5 w-5 text-cyan-400" />
                                <span className="text-base font-semibold text-white/90">{userName}</span>
                            </div>
                            <Button
                                variant="ghost"
                                size="icon"
                                onClick={onClose}
                                className="pointer-events-auto text-white/80 hover:text-white hover:bg-white/10 rounded-full backdrop-blur-sm"
                            >
                                <X className="h-6 w-6" />
                            </Button>
                        </div>

                        {/* Center Content */}
                        <div className="flex-1 flex flex-col items-center justify-center relative">
                            {/* Tampilan "Siap Memindai" (Hanya muncul jika kamera BELUM start) */}
                            {!cameraStarted && (
                                <div className="flex flex-col items-center gap-8 max-w-md text-center pointer-events-auto">
                                    {isLoadingModels ? (
                                        <>
                                            <Loader2 className="h-16 w-16 animate-spin text-cyan-400" />
                                            <p className="text-lg text-white/90">{feedback}</p>
                                        </>
                                    ) : (
                                        <>
                                            <ScanFace className="h-24 w-24 text-cyan-400 opacity-80" strokeWidth={1.2} />
                                            <h2 className="text-2xl md:text-3xl font-bold text-white">Siap Memindai Wajah</h2>
                                            <p className="text-white/70 text-base leading-relaxed">
                                                Pastikan pencahayaan cukup dan wajah terlihat jelas.
                                            </p>

                                            {cameraError && (
                                                <p className="text-red-400 text-sm mt-2 bg-red-900/20 px-3 py-1 rounded">{cameraError}</p>
                                            )}

                                            <Button
                                                onClick={startCameraAndDetection}
                                                size="lg"
                                                className="mt-6 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-10 py-7 rounded-xl shadow-lg shadow-cyan-900/40 transition-all active:scale-95"
                                            >
                                                <Camera className="mr-3 h-6 w-6" />
                                                Buka Kamera
                                            </Button>
                                        </>
                                    )}
                                </div>
                            )}

                            {/* Tampilan Scanning Frame (Muncul jika kamera SUDAH start) */}
                            {cameraStarted && step !== 'success' && (
                                <div className={`relative w-72 h-96 md:w-80 md:h-112 border-4 rounded-[45%] overflow-hidden transition-colors duration-300 
                                    ${step === 'match' ? 'border-cyan-400/60' : 'border-emerald-400/60'} shadow-2xl shadow-black/60`}>

                                    {step === 'match' && !isCameraWarmingUp && (
                                        <div className="absolute inset-x-0 h-1 bg-cyan-400/60 blur-sm animate-scan-line shadow-[0_0_20px_rgba(34,211,238,0.7)]" />
                                    )}
                                    <div className="absolute inset-0 border-2 border-white/10 rounded-[45%]" />

                                    {/* Overlay loading jika model belum siap */}
                                    {isLoadingModels && (
                                        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm">
                                            <Loader2 className="h-14 w-14 animate-spin text-cyan-300 mb-4" />
                                            <p className="text-white text-lg font-semibold">Memuat model AI, mohon tunggu...</p>
                                        </div>
                                    )}

                                    {/* Overlay warming up kamera */}
                                    {isCameraWarmingUp && !isLoadingModels && (
                                        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm">
                                            <Loader2 className="h-12 w-12 animate-spin text-cyan-200 mb-3" />
                                            <p className="text-white text-base font-semibold">Menyiapkan kamera...</p>
                                        </div>
                                    )}
                                </div>
                            )}

                            {/* Tampilan Success */}
                            {cameraStarted && step === 'success' && (
                                <div className="flex flex-col items-center justify-center gap-6 animate-fade-in-up">
                                    <div className="relative">
                                        <CheckCircle2 className="h-28 w-28 text-emerald-400 animate-check-pop" strokeWidth={1.5} />
                                        <div className="absolute inset-0 bg-emerald-400/10 rounded-full blur-3xl animate-pulse" />
                                    </div>
                                    <h2 className="text-4xl font-bold text-white">Berhasil</h2>
                                </div>
                            )}
                        </div>

                        {/* Footer Status Bar (Hanya jika kamera aktif) */}
                        {cameraStarted && step !== 'success' && (
                            <div className="w-full max-w-md mx-auto bg-black/65 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-xl pointer-events-auto mb-8">
                                <p className="text-xl md:text-2xl font-bold text-center text-white mb-3 tracking-wide">
                                    {feedback}
                                </p>
                                <p className="text-sm text-white/70 text-center mb-2">
                                    {getProgressLabel()}
                                </p>
                                <div className="mt-3 flex items-center justify-between gap-2">
                                    {[1, 2, 3].map((progressStep) => (
                                        <div
                                            key={progressStep}
                                            className={`h-2 w-full rounded-full transition-colors duration-300 ${getStepNumber() >= progressStep ? 'bg-emerald-400/80' : 'bg-white/15'}`}
                                        />
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}