<?php

namespace App\Providers;

use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\ServiceProvider;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\URL;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        if (app()->environment(['production', 'staging']) && !app()->runningInConsole()) {
            $localHosts = ['localhost', '127.0.0.1', '::1'];
            $requestHost = request()->getHost();

            if (!in_array($requestHost, $localHosts, true)) {
                URL::forceScheme('https');
            }
        }
        $this->configureDefaults();
    }

    protected function configureDefaults(): void
    {
        Date::use(CarbonImmutable::class);

        DB::prohibitDestructiveCommands(
            app()->isProduction(),
        );

        Password::defaults(
            fn(): ?Password => app()->isProduction()
                ? Password::min(8)
                // Configure default password rules for testing
                // ->mixedCase()
                // ->letters()
                // ->numbers()
                // ->symbols()
                // ->uncompromised()
                : null
        );
    }
}
